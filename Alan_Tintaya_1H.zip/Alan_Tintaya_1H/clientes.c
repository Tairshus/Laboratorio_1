#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
//#include "afiches.h"
#include "clientes.h"
#include "utn.h"

/** \brief Devuelve siempre el siguiente numero de ID disponible
*
*/
static int getNextId()
{
    static int id = 1;
    return id++;
}

/** \brief Devuelve el indice del primer elemento vacio en el array
*
* \param array eCliente*
* \param tamanio int
* \param return retorno (-1) si no encuentra un espacio disponible para cargar un empleado - (i) retorna el indice del espacio encontrado
*
*/
int devolverIndice(eCliente* array,int tamanio)
{
    int retorno=-1;
    int i;

    for(i=0;i<tamanio;i++)
    {
        if(array[i].isEmpty)
        {
            retorno=i;
            break;
        }
    }
    return retorno;
}

/** \brief Para indicar que todas las posiciones del array están vacías, esta función pone la bandera
    (isEmpty) en TRUE en todas las posiciones del array.
 * \param list eCliente* Puntero al array de eCliente
 * \param len int Array tamaño
 * \return int Return (-1) if Error [Invalid length or NULL pointer] - (0) if Ok
 *
 */
int cl_initCliente(eCliente* pBuffer,int len)
{
    int retorno = -1;
    if (pBuffer != NULL && len>0)
    {
        int i;
        for(i=0;i<len;i++)
        {
            pBuffer[i].isEmpty=1;
        }
        retorno = 0;
    }

 return retorno;
}

/** \brief Da de alta un cliente en la primer posicion vacia del array
 * \param pBuffer eCliente*
 * \param len int
 * \param indice int
 * \return Retorna 0 si no hubo problemas o (-1) si el array es igual NULL
  o el tamaño es invalido o se ingresa mal los datos repetidas veces
  o si el array esta lleno
*
*/
int cl_altaCliente (eCliente* pBuffer,int len,int indice)
{
    int retorno =-1;
    char auxNombre[51];
    char auxApellido[51];
    char auxCuit[10];

    __fpurge(stdin);

    if(pBuffer!=NULL && len>0 && indice>=0 && indice<len)
    {
        if(!utn_getNombre(auxNombre,51,"\nNombre: ","\nInvalido",2) &&
         !utn_getNombre(auxApellido,51,"\nApellido: ","\nInvalido",2) &&
         !utn_getLetrasYNumeros(auxCuit,10,"Cuit: "))
        {
            strncpy(pBuffer[indice].nombre,auxNombre,51);
            strncpy(pBuffer[indice].apellido,auxApellido,51);
            strncpy(pBuffer[indice].cuit,auxCuit,10);
            pBuffer[indice].isEmpty = 0;
            pBuffer[indice].id = getNextId();

            retorno = 0;
        }
    }
    return retorno;
}

/** \brief Permite modificar los datos del cliente indicado
* \param list eCliente*
* \param len int
* \return int Return (-1) if Error [Tamaño invalido o Puntero en NULL o Cliente no encontrado] - (0) if Ok
*
*/
int cl_modificarCliente(eCliente* list,int len)
{
    __fpurge(stdin);
    int retorno = -1;
    if(list != NULL && len > 0)
    {
        char auxId[20];
        char auxName[51];
        char auxLastName[51];
        int opcion;
        char auxCuit[10];
        int id;

        if (utn_getSoloInt(auxId,20,"\nIngrese ID: ","\nID invalido: ",2)==0)
        {
            id = atoi(auxId);
            id = findClientById(list,len,id);
            if (id != -1)
            {
                system("clear");
                do{
                    printf("\nIndique que desea modificar\n1)Nombre\n2)Apellido\n3)Cuit\n4)Guardar y salir\n");
                    __fpurge(stdin);
                    scanf("%d",&opcion);


                    switch(opcion)
                    {
                    case 1:
                        if(!utn_getNombre(auxName,51,"\nNombre: ","\nInvalido",2))
                        {
                            strncpy(list[id].nombre,auxName,51);
                        }
                        break;
                    case 2:
                        if(!utn_getNombre(auxLastName,51,"\nApellido: ","\nInvalido",2))
                        {
                            strncpy(list[id].apellido,auxLastName,51);
                        }
                        break;
                    case 3:
                        if(utn_getLetrasYNumeros(auxCuit,10,"Cuit: ")==0)
                        {
                            strncpy(list[id].cuit,auxCuit,10);
                        }
                        break;
                    case 4:
                        printf("Guardando y saliendo...");
                        break;
                    default:
                        printf("Opcion invalida.");
                    }
                    __fpurge(stdin);//para limpiar el buffer.
                    printf("\nIngrese ENTER para continuar");
                    getchar(); //te freeza hasta que apretas una letra.
                    system("clear"); //limpia la pantalla
                }while(opcion != 4);
                retorno = 0;
            }
            else
            {
                printf("No se ha encontrado el empleado.");
            }
        }
    }
    return retorno;
}

/** \brief Encuentra un clien mediante el ID proporcionado
 *
 * \param list eCliente*
 * \param len int
 * \param id int
 * \return Return 0 si encuentra el cliente o (-1) si el array es igual a NULL o el tamaño es invalido
  o el cliente no existe
*/
int findClientById(eCliente* list, int len,int id)
{
    int i;
    int retorno = -1;
    if (list != NULL && len > 0)
    {
        for(i=0;i<len;i++)
        {
            if(list[i].id == id && list[i].isEmpty == 0)
            {
                retorno = i;
                break;
            }
        }
    }
 return retorno;
}



int cl_ingresoForzado(eCliente* pBuffer,int limite,char* nombre,char* cuit,char* apellido)
{
    int aux;
    aux = devolverIndice(pBuffer,limite);
    strcpy(pBuffer[aux].nombre,nombre);
    strcpy(pBuffer[aux].cuit,cuit);
    strcpy(pBuffer[aux].apellido,apellido);
    pBuffer[aux].id = getNextId();
    pBuffer[aux].isEmpty = 0;

    return 0;
}
