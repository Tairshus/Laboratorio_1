#ifndef INFORMES_H_INCLUDED
#define INFORMES_H_INCLUDED
#include "afiches.h"
#include "clientes.h"

int cantidadDeACobrar(eAfiche* pAfiche,int limiteA,int clienteID);
int printClientes(eCliente* list,eAfiche* afList,int lenC,int lenA);
int printVentas(eAfiche* pAfiches,int lenA);
int clienteMenosACobrar(eCliente* pCliente,eAfiche* pAfiches,int lenC,int lenA);
void printCliente(eCliente* pCliente,int i);
int informar(eCliente* pCliente,eAfiche* pAfiche,int lenC,int lenA);
int clienteMenosVentas(eCliente* pCliente,eAfiche* pAfiches,int lenC,int lenA);
int cantidadDeVentas(eAfiche* pAfiche,int limiteA,int clienteID);
int cantidadDeCobradas(eAfiche* pAfiche,int limiteA,int clienteID);
int cantidadDeVentas(eAfiche* pAfiche,int limiteA,int clienteID);
void zonaMasAfiches(eAfiche pAfiche,int* zonaC,int* zonaO,int* zonaS);
int clienteMenosCobradas(eCliente* pCliente,eAfiche* pAfiches,int lenC,int lenA);
int zonaMasAfichesVendidos(eAfiche* pAfiches,int lenA);
void clienteMenosAfiches(eCliente* pCliente,eAfiche* pAfiche,int lenC,int lenA);

#endif
