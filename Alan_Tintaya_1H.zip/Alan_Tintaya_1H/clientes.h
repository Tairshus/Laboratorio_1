#ifndef CLIENTES_H_INCLUDED
#define CLIENTES_H_INCLUDED
typedef struct
{
    char nombre[51];
    char apellido[51];
    char cuit[10];
    int id;
    int isEmpty;
}eCliente;

int cl_altaCliente(eCliente* pBuffer,int len,int indice);
int cl_modificarCliente (eCliente* pBuffer,int len);
int cl_initCliente(eCliente* pBuffer,int len);
int findClientById(eCliente* list, int len,int id);
int devolverIndice(eCliente* array,int tamanio);
int cl_printClientes(eCliente* list,int len);
int cl_bajaCliente(eCliente* list, int len, int id);
//int cl_ingresoForzado(eCliente*,int,char*,char*,char*)

#endif
