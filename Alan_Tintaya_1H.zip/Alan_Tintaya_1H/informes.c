#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include "clientes.h"
#include "afiches.h"
#include "informes.h"
#include "utn.h"

int informar(eCliente* pCliente,eAfiche* pAfiche,int lenC,int lenA)
{
int opcion;

    do
    {
        printf("1)Cliente con menos ventas a cobrar. \n2)Cliente con menos ventas cobradas.\n3)Cliente con menos ventas. \n4)Zona con mas afiches vendidos.");
        printf("\n5)Cliente que compro menos afiches\n6)Cliente con mas afiches a cobrar\n7)Cantidad de clientes que compraron mas de 500 afiches\n8)Cantidad de afiches vendidos por cada una de las 3 zonas");
        printf("\n9)Cantidad de afiches vendidos promedio por cliente\n10)Listar ventas ordenadas por zona\n11)Volver al menu principal\n");
        scanf("%d",&opcion);
        switch(opcion)
        {
            case 1:
                clienteMenosACobrar(pCliente,pAfiche,lenC,lenA);
            break;

            case 2:
                clienteMenosCobradas(pCliente,pAfiche,lenC,lenA);
            break;

            case 3:
                clienteMenosVentas(pCliente,pAfiche,lenC,lenA);
            break;

            case 4:
                zonaMasAfichesVendidos(pAfiche,lenA);
            break;

            case 5:
                clienteMenosAfiches(pCliente,pAfiche,lenC,lenA);
            break;

            case 11:
                printf("Volviendo.");
            break;

            default:
            break;
        }
    __fpurge(stdin);//para limpiar el buffer.
    printf("\nIngrese ENTER para continuar");
    getchar(); //te freeza hasta que apretas una letra.
    system("clear"); //limpia la pantalla

    }while(opcion != 11);
    return 0;
}

/** \brief Devuelve el numero de ventas que posee el cliente recorriendo el array de eAfiche
 *
 * \param list eCliente*
 * \param len int
 * \param id int
 * \return int Return (-1) if Error [Invalid length or NULL pointer or if can't
find a employee] - (0) if Ok
*/
int cantidadDeACobrar(eAfiche* pAfiche,int limiteA,int clienteID)
{
    int retorno = 0;
    int i;
    for(i=0;i<limiteA;i++)
    {
        if (clienteID == pAfiche[i].idCliente && pAfiche[i].isEmpty == 0 && strcmp(pAfiche[i].estado,"a cobrar") == 0)
        {
            retorno++;
        }
    }
    return retorno;
}

int cantidadDeCobradas(eAfiche* pAfiche,int limiteA,int clienteID)
{
    int retorno = 0;
    int i;
    for(i=0;i<limiteA;i++)
    {
        if (clienteID == pAfiche[i].idCliente && pAfiche[i].isEmpty == 0 && strcmp(pAfiche[i].estado,"Cobrada") == 0)
        {
            retorno++;
        }
    }
    return retorno;
}

int cantidadDeVentas(eAfiche* pAfiche,int limiteA,int clienteID)
{
    int retorno = 0;
    int i;
    for(i=0;i<limiteA;i++)
    {
        if (clienteID == pAfiche[i].idCliente && pAfiche[i].isEmpty == 0)
        {
            retorno++;
        }
    }
    return retorno;
}

/** \brief imprime el contenido del array de Clientes
 *
 * \param list eCliente*
 * \param afList eAfiche*
 * \param lenC int
 * \param lenA int
 * \return int (0) si encuentra clientes cargados - int (-1) si el array esta vacio o el tama�o del array es invalido
 *
 */
int printClientes(eCliente* list,eAfiche* afList,int lenC,int lenA)
{
    int i;
    int retorno = -1;
    int ventas;
    if(list != NULL && lenC >0)
    {
        for(i=0;i<lenC;i++)
        {
            if(list[i].isEmpty == 0)
            {
                ventas = cantidadDeACobrar(afList,lenA,list[i].id);
                printCliente(list,i);
                printf("\nVentas: %d",ventas);
                printf("\n---------------");
            }
        }
        retorno = 0;
    }
    else
    {
        printf("\nError.");
    }
 return retorno;
}

void printCliente(eCliente* pCliente,int i)
{
    printf("\nID: %d",pCliente[i].id);
    printf("\nNombre: %s",pCliente[i].nombre);
    printf("\nApellido: %s",pCliente[i].apellido);
    printf("\nCuit: %s",pCliente[i].cuit);
}

/** \brief imprime el todas las ventas en estado "a cobrar"
 *
 * \param pAfiches eAfiche*
 * \param lenA int
 * \return int (0) ventas - int (-1) si el array esta vacio o el tama�o del array es invalido
 *
 */
int printVentas(eAfiche* pAfiches,int lenA)
{
    int i;
    int retorno = -1;
    if (pAfiches != NULL && lenA > 0)
    {
        for (i=0;i<lenA;i++)
        {
            if(pAfiches[i].isEmpty == 0 && strcmp(pAfiches[i].estado,"a cobrar")==0)
            {
                printf("\nID: %d",pAfiches[i].id);
                printf("\nNombre del archivo: %s",pAfiches[i].nombreArch);
                printf("\nZona: %s",pAfiches[i].zona);
                printf("\nCantidad: %d",pAfiches[i].afichesCant);
                printf("\nEstado: %s\n",pAfiches[i].estado);
            }
        }
        retorno = 0;
    }
    else
    {
        printf("\nError.");
    }
    return retorno;
}

int clienteMenosACobrar(eCliente* pCliente,eAfiche* pAfiches,int lenC,int lenA)
{
    int retorno = -1;
    int i;
    int flagg = 0;
    int menorVentas;
    int indice;

    if(pCliente != NULL && pAfiches != NULL && lenC > 0 && lenA > 0)
    {
        for(i=0;i<lenC;i++)
        {
            if(flagg == 0 && pCliente[i].isEmpty == 0)
            {
                menorVentas = cantidadDeACobrar(pAfiches,lenA,pCliente[i].id);
                indice = i;
                flagg++;
            }
            else if(flagg != 0 && pCliente[i].isEmpty == 0 && menorVentas > cantidadDeACobrar(pAfiches,lenA,pCliente[i].id))
            {
                menorVentas = cantidadDeACobrar(pAfiches,lenA,pCliente[i].id);
                indice = i;
            }
        }
        printf("El cliente con menos ventas a cobrar es:");
        printCliente(pCliente,indice);
        printf("\nVentas: %d\n",menorVentas);
        retorno = 0;
    }

    return retorno;
}


int clienteMenosCobradas(eCliente* pCliente,eAfiche* pAfiches,int lenC,int lenA)
{
    int retorno = -1;
    int i;
    int flagg = 0;
    int menorCobradas;
    int indice;

    if(pCliente != NULL && pAfiches != NULL && lenC > 0 && lenA > 0)
    {
        for(i=0;i<lenC;i++)
        {
            if(flagg == 0)
            {
                menorCobradas = cantidadDeCobradas(pAfiches,lenA,pCliente[i].id);
                indice = i;
                flagg++;
            }
            else if(flagg != 0 && menorCobradas > cantidadDeCobradas(pAfiches,lenA,pCliente[i].id))
            {
                menorCobradas = cantidadDeCobradas(pAfiches,lenA,pCliente[i].id);
                indice = i;
            }
        }
        printf("El cliente con menos ventas cobradas es:");
        printCliente(pCliente,indice);
        printf("\nCobradas: %d\n",menorCobradas);
        retorno = 0;
    }

    return retorno;
}

int clienteMenosVentas(eCliente* pCliente,eAfiche* pAfiches,int lenC,int lenA)
{
    int retorno = -1;
    int i;
    int flagg = 0;
    int menorVentas;
    int indice;

    if(pCliente != NULL && pAfiches != NULL && lenC > 0 && lenA > 0)
    {
        for(i=0;i<lenC;i++)
        {
            if(flagg == 0 && pCliente[i].isEmpty == 0)
            {
                menorVentas = cantidadDeVentas(pAfiches,lenA,pCliente[i].id);
                indice = i;
                flagg++;
            }
            else if(flagg != 0 && pCliente[i].isEmpty == 0 && menorVentas > cantidadDeVentas(pAfiches,lenA,pCliente[i].id))
            {
                menorVentas = cantidadDeVentas(pAfiches,lenA,pCliente[i].id);
                indice = i;
            }
        }
        printf("El cliente con menos ventas es:");
        printCliente(pCliente,indice);
        printf("\nVentas: %d\n",menorVentas);
        retorno = 0;
    }

    return retorno;
}

int zonaMasAfichesVendidos(eAfiche* pAfiches,int lenA)
{
    int i;
    int retorno= -1;
    int zonaC = 0;
    int zonaS = 0;
    int zonaO = 0;


    if(pAfiches != NULL && lenA > 0)
    {
        for(i=0;i<lenA;i++)
        {
            if(pAfiches[i].isEmpty == 0)
            {
                    if(strcmp(pAfiches[i].zona,"caba")==0)
                    {
                        zonaC = zonaC + pAfiches[i].afichesCant;
                    }
                    if(strcmp(pAfiches[i].zona,"zona sur")==0)
                    {
                        zonaS = zonaS + pAfiches[i].afichesCant;
                    }
                    if(strcmp(pAfiches[i].zona,"zona oeste")==0)
                    {
                        zonaO = zonaO + pAfiches[i].afichesCant;
                    }
            }
        }
        if(zonaC > zonaS && zonaC > zonaO)
        {
            printf("\nLa zona con mas afiches vendidos es CABA");
        }
        else if(zonaS > zonaC && zonaS > zonaO)
        {
            printf("\nLa zona con mas afiches vendidos es Zona Sur");
        }
        else if (zonaO > zonaS && zonaO > zonaC)
        {
            printf("\nLa zona con mas afiches vendidos es Zona Oeste");
        }
        else
        {
            printf("\nTodas las zonas poseen el mismo numero de ventas");
        }
        retorno = 0;

    }

    return retorno;
}

void clienteMenosAfiches(eCliente* pCliente,eAfiche* pAfiche,int lenC,int lenA)
{
    int i;
    int idC;
    int cantAf = 0;
    int cantAfNew = 0;
    int flagg = 0;
    int j;
if(pCliente != NULL && pAfiche != NULL && lenC > 0 && lenA > 0)
{
    for(i=0;i<lenC;i++)
    {
        if(flagg == 0 && pCliente[i].isEmpty == 0)
        {
            for(j=0;j<lenA;j++)
            {
                if(pCliente[i].id == pAfiche[j].idCliente)
                {
                    cantAf = cantAf + pAfiche[j].afichesCant;
                }
            }
            idC = i;
            flagg++;
        }
        else if(flagg != 0 && pCliente[i].isEmpty == 0)
        {
            for(j=0;j<lenA;j++)
            {
                if(pCliente[i].id == pAfiche[j].idCliente)
                {
                    cantAfNew = cantAfNew + pAfiche[j].afichesCant;
                }
            }
            if(cantAf > cantAfNew)
            {
                cantAf = cantAfNew;
                cantAfNew = 0;
                idC = i;
            }
            else
            {
                cantAfNew = 0;
            }
        }
    }

    printf("\nEl cliente que compro menos afiches es:");
    printf("%d",idC);
    printCliente(pCliente,idC);
    printf("\nEl cual compro %d afiches",cantAf);
    }
}

/*int clienteMasAfichesCobrar(eCliente* pCliente,eAfiche* pAfiche,int lenC,int len A)
{
    int retorno = -1;
    int i;



    return retorno;
}*/

//int afichesACobrar()
