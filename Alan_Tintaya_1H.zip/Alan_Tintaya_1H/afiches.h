#ifndef AFICHES_H_INCLUDED
#define AFICHES_H_INCLUDED
#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include "clientes.h"
#include "utn.h"

typedef struct
{
    int idCliente;
    int afichesCant;
    char nombreArch[51];
    char zona[10];
    int id;
    char estado[10];
    int isEmpty;
}eAfiche;

int af_altaAfiche (eCliente* pCliente,eAfiche* pAfiche,int lenC,int lenA,int indice);
int af_editarAfiche (eAfiche*,int);
int af_initAfiches(eAfiche*,int);
int af_findAficheById(eAfiche* list, int len,int id);
int af_devolverIndice(eAfiche* array,int tamanio);
int af_printAfiche(eAfiche* list,int len);
int af_cobrarAfiche(eAfiche* list, int len, int id);
int af_findClientById(eCliente* list, int len,int id);
int af_ingresoForzado(eAfiche*,int,int,int,char*,char*);

#endif
