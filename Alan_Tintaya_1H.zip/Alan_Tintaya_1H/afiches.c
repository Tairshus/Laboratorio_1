#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
//#include "clientes.h"
#include "afiches.h"
#include "utn.h"
#include "informes.h"

/** \brief Devuelve siempre el siguiente numero de ID disponible
*
*/
static int af_getNextId()
{
    static int id = 1;
    return id++;
}

/** \brief Usando un id proporcionado, busca la posicion del array que contenga esa ID
 *
 * \param list eAfiche*
 * \param len int
 * \param id int
 * \return Retorna la posicion buscada en el array o -1 si no encuentra el ID o el tama�o
  es invalido o el array es igual a NULL
*/
int findVentaById(eAfiche* list, int len,int id)
{
    int i;
    int retorno = -1;
    if (list != NULL && len > 0)
    {
        for(i=0;i<len;i++)
        {
            if(list[i].id == id && list[i].isEmpty == 0 && strcmp(list[i].estado,"a cobrar")==0)
            {
                retorno = i;
                break;
            }
        }
    }
 return retorno;
}

/** \brief Inicializa todas las posiciones del array en 1
 *
 * \param pBuffer eAfiche*
 * \param len int
 * \return Retorna 0 si no hubo problemas o -1 si el tama�o es invalido o el array es igual a NULL
*/
int af_initAfiches(eAfiche* pBuffer,int len)
{
    int retorno = -1;
    if (pBuffer != NULL && len>0)
    {
        int i;
        for(i=0;i<len;i++)
        {
            pBuffer[i].isEmpty=1;
        }
        retorno = 0;
    }

 return retorno;
}

/** \brief Encuentra la posicion de un cliente en el array mediante un ID
 *
 * \param list eCliente*
 * \param len int
 * \param id int
 * \return Retorna la posicion del cliente o (-1) si no ha podido encontrarlo
*/
int af_findClientById(eCliente* list, int len,int id)
{
    int i;
    int retorno = -1;
    if (list != NULL && len > 0)
    {
        for(i=0;i<len;i++)
        {
            if(list[i].id == id)
            {
                retorno = i;
                break;
            }
        }
    }
 return retorno;
}

/** \brief Pide un ID de cliente valido y da de alta una venta en el mismo
 *
 * \param pCliente eCliente*
 * \param pAfiche eAfiche*
 * \param lenC int
 * \param lenA int
 * \return Returna 0 si la venta es completa exitosamente (-1) si el ID ingresado
  no existe o no queda espacio en el array o el usuario ingresa mal los datos varias veces
*/
int af_altaAfiche (eCliente* pCliente,eAfiche* pAfiche,int lenC,int lenA)
{
    __fpurge(stdin);
    int indice = af_devolverIndice(pAfiche,lenA);
    int retorno = -1;
    char auxId[20];
    char auxAfCant[5];
    char auxNbrArch[51];
    char auxZona[15];
    char auxZonaF[15];
    int id;
    int afCant;
    int reintentos = 0;

    if(pCliente != NULL && pAfiche != NULL && lenC > 0 && lenA > 0 && indice != -1)
    {


        if (utn_getSoloInt(auxId,20,"\nIngrese ID: ","\nID invalido: ",2)==0)
        {
            id = atoi(auxId);

            if(findClientById(pCliente,lenC,id) != -1 && !utn_getSoloInt(auxAfCant,4,"\nIngrese cantidad de afiches: ","\nCantidad invalida.",2) &&
                !utn_getLetrasYNumeros(auxNbrArch,51,"\nIngrese nombre del archivo: "))
            {
                printf("\nIngrese zona: ");
                __fpurge(stdin);
                fgets(auxZona,15,stdin);
                strcpy(auxZonaF,auxZona);
                utn_toLowerWord(auxZonaF);
                while(strcmp(auxZonaF,"caba") != 0 && strcmp(auxZonaF,"zona sur") != 0 && strcmp(auxZonaF,"zona oeste") != 0 && reintentos != 3)
                {
                    reintentos++;
                    printf("\nError,ingrese una zona valida: ");
                    __fpurge(stdin);
                    fgets(auxZona,15,stdin);
                    strcpy(auxZonaF,auxZona);
                    utn_toLowerWord(auxZonaF);
                    printf("\n%s",auxZonaF);
                }
                if(reintentos != 3)
                {
                    afCant = atoi(auxAfCant);
                    pAfiche[indice].idCliente = id;
                    strcpy(pAfiche[indice].estado,"a cobrar");
                    pAfiche[indice].afichesCant = afCant;
                    pAfiche[indice].id = af_getNextId();
                    pAfiche[indice].isEmpty = 0;
                    strncpy(pAfiche[indice].nombreArch,auxNbrArch,51);
                    strcpy(pAfiche[indice].zona,auxZona);
                    printf("\nID de la venta: %d\n",pAfiche[indice].id);
                    retorno = 0;
                }
                else
                {
                    printf("\nHa superado el numero maximo de intentos.");
                }
            }
            else
            {
                printf("Error.");
            }
        }
    }
    else if (indice == -1)
    {
        printf("\nNo queda espacio para agregar afiches");
    }
    else
    {
        printf("\nError.");
    }

    return retorno;
}

/** \brief Devuelve el primer indice vacio del array de afiches
 *
 * \param array eAfiche*
 * \param tamanio int
 * \return Retorna el indice disponible o (-1) si no encuentra un espacio disponible
*/
int af_devolverIndice(eAfiche* array,int tamanio)
{
    int retorno=-1;
    int i;

    for(i=0;i<tamanio;i++)
    {
        if(array[i].isEmpty == 1)
        {
            retorno=i;
            break;
        }
    }
    return retorno;
}

/** \brief Elimina un cliente y todas sus ventas cambiando sus isEmpty a 1
 *
 * \param list eCliente*
 * \param pAfiches eAfiche*
 * \param lenC int
 * \param lenA int
 * \return Retorna 0 si no hubo problemas o -1 si no encuentra el cliente o el tama�o
  es invalido o el array es igual a NULL
*/
int bajaClienteYVentas(eCliente* list,eAfiche* pAfiches, int lenC,int lenA)
{
    int id;
    int i;
    int indice;
    char auxId[20];
    char pulsa;
    __fpurge(stdin);
    int retorno = -1;
    if (list != NULL && lenC > 0)
    {

        if (utn_getSoloInt(auxId,20,"\nIngrese ID: ","\nID invalido: ",2)==0)
        {
            id = atoi(auxId);
            indice = findClientById(list,lenC,id);

            if (findClientById(list,lenC,id) != -1)
            {
                printf("Ha seleccionado al cliente.\nNombre: %s\nApellido: %s\nCuit: %s\nSeguro que desea continuar? Pulse 'S' para continuar\n",list[indice].nombre,list[indice].apellido,list[indice].cuit);
                __fpurge(stdin);
                scanf("%c",&pulsa);
                if(pulsa == 's' || pulsa == 'S')
                {
                    list[indice].isEmpty = 1;
                    for(i=0;i<lenA;i++)
                    {
                        if(id == pAfiches[i].idCliente)
                        {
                            pAfiches[i].isEmpty = 1;
                        }
                    }

                    retorno =0;
                }
            }
            else
            {
                printf("\nCliente no encontrado.\n");
            }

        }
    }
 return retorno;
}

/** \brief Permite modificar la cantidad y la zona de una venta
 *
 * \param pAfiches eAfiche*
 * \param len int
 * \return Retorna 0 si no hubo problemas o -1 si no encuentra la venta o el tama�o
  es invalido o el array es igual a NULL
*/
int af_modificarVenta(eAfiche* pAfiches,int len)
{
    int id;
    int indice;
    char auxId[20];
    char auxCantidad[5];
    int cantidad;
    char auxZona[20];
    int reintentos = 0;
    char auxZonaF[20];
    int opcion;
    __fpurge(stdin);
    int retorno = -1;
    if (pAfiches != NULL && len > 0)
    {
        printVentas(pAfiches,len);
        if (utn_getSoloInt(auxId,20,"\nIngrese el ID de la venta: ","\nID invalido: ",2)==0)
        {
            id = atoi(auxId);
            indice = findVentaById(pAfiches,len,id);
            if (indice != -1)
            {
                system("clear");
                do{
                    printf("\nIndique que desea modificar\n1)Cantidad de afiches\n2)Zona\n3)Guardar y salir\n");
                    scanf("%d",&opcion);
                    __fpurge(stdin);

                    switch(opcion)
                    {
                    case 1:
                        if(!utn_getSoloInt(auxCantidad,4,"\nIngrese cantidad de afiches: ","\nCantidad invalida.",2))
                        {
                            cantidad = atoi(auxCantidad);
                            pAfiches[indice].afichesCant = cantidad;
                        }
                        break;
                    case 2:
                        printf("\nIngrese zona: ");
                        __fpurge(stdin);
                        fgets(auxZona,15,stdin);
                        strcpy(auxZonaF,auxZona);
                        utn_toLowerWord(auxZonaF);
                        while(strcmp(auxZonaF,"caba") != 0 && strcmp(auxZonaF,"zona sur") != 0 && strcmp(auxZonaF,"zona oeste") != 0 && reintentos != 3)
                        {
                            reintentos++;
                            printf("\nError,ingrese una zona valida: ");
                            __fpurge(stdin);
                            fgets(auxZona,15,stdin);
                            strcpy(auxZonaF,auxZona);
                            utn_toLowerWord(auxZonaF);
                            printf("\n%s",auxZonaF);
                        }
                        if (reintentos != 3)
                        {
                            strcpy(pAfiches[indice].zona,auxZona);
                        }
                        else
                        {
                            printf("Ha superado el numero de intentos.");
                        }
                        break;
                    case 3:
                        printf("Guardando y saliendo...");
                        break;
                    default:
                        printf("Opcion invalida.");
                    }
                    __fpurge(stdin);//para limpiar el buffer.
                    printf("\nIngrese ENTER para continuar");
                    getchar(); //te freeza hasta que apretas una letra.
                    system("clear"); //limpia la pantalla
                }while(opcion != 3);
                retorno = 0;
            }
            else
            {
                printf("No se ha encontrado el ID de venta.");
            }
        }
    }
    return retorno;
}

/** \brief Permite cobrar una venta
 *
 * \param pAfiches eAfiche*
 * \param len int
 * \return Retorna 0 si no hubo problemas o -1 si no encuentra la venta o el tama�o
  es invalido o el array es igual a NULL
*/
int af_cobrarVenta(eAfiche* pAfiches,int len)
{
    int id;
    int indice;
    char auxId[20];
    __fpurge(stdin);
    int retorno = -1;
    if (pAfiches != NULL && len > 0)
    {
        printVentas(pAfiches,len);
        if (utn_getSoloInt(auxId,20,"\nIngrese ID: ","\nID invalido: ",2)==0)
        {
            id = atoi(auxId);
            indice = findVentaById(pAfiches,len,id);

            if (indice != -1)
            {
                strcpy(pAfiches[indice].estado,"Cobrada");

                retorno =0;
            }
            else
            {
                printf("\nVenta no encontrada.\n");
            }

        }
    }
 return retorno;
}

int af_ingresoForzado(eAfiche* pAfiche,int limite,int idC,int cantidad,char* archivo,char* zona)
{
    int aux;
    aux = af_devolverIndice(pAfiche,limite);
    strcpy(pAfiche[aux].nombreArch,archivo);
    strcpy(pAfiche[aux].zona,zona);
    strcpy(pAfiche[aux].estado,"a cobrar");
    pAfiche[aux].id = af_getNextId();
    pAfiche[aux].idCliente = idC;
    pAfiche[aux].afichesCant = cantidad;
    pAfiche[aux].isEmpty = 0;

    return 0;
}
