#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include "clientes.h"
#include "afiches.h"
#include "utn.h"

static int af_getNextId()
{
    static int id = 1;
    return id++;
}

int af_initAfiches(eAfiche* pBuffer,int len)
{
    int retorno = -1;
    if (pBuffer != NULL && len>0)
    {
        int i;
        for(i=0;i<len;i++)
        {
            pBuffer[i].isEmpty=1;
        }
        retorno = 0;
    }

 return retorno;
}

/** \brief find an eCliente by Id en returns the index position in array.
 *
 * \param list eCliente*
 * \param len int
 * \param id int
 * \return Return client index position or (-1) if [Invalid length or NULL
pointer received or client not found]
*/
int af_findClientById(eCliente* list, int len,int id)
{
    int i;
    int retorno = -1;
    if (list != NULL && len > 0)
    {
        for(i=0;i<len;i++)
        {
            if(list[i].id == id)
            {
                retorno = i;
                break;
            }
        }
    }
 return retorno;
}

int af_altaAfiche (eCliente* pCliente,eAfiche* pAfiche,int lenC,int lenA,int indice)
{
    __fpurge(stdin);
    int retorno = -1;
    char auxId[20];
    char auxAfCant[5];
    char auxNbrArch[51];
    char auxZona[15];
    char auxZonaF[15];
    int id;
    int afCant;
    int reintentos = 0;

    if(pCliente != NULL && pAfiche != NULL && lenC > 0 && lenA > 0)
    {


        if (utn_getSoloInt(auxId,20,"\nIngrese ID: ","\nID invalido: ",2)==0)
        {
            id = atoi(auxId);
            id = findClientById(pCliente,lenC,id);
            if(id != -1 && !utn_getSoloInt(auxAfCant,4,"\nIngrese cantidad de afiches: ","\nCantidad invalida.",2) &&
                !utn_getLetrasYNumeros(auxNbrArch,51,"\nIngrese nombre del archivo: "))
            {
                printf("\nIngrese zona: ");
                __fpurge(stdin);
                scanf("%s",auxZona);
                strcpy(auxZonaF,utn_toLowerWord(auxZona));
                while(auxZonaF != "caba" && auxZonaF != "zona sur" && auxZonaF != "zona oeste" && reintentos != 3)
                {
                    reintentos++;
                    printf("\nError,ingrese una zona valida: ");
                    __fpurge(stdin);
                    scanf("%s",auxZona);
                    strcpy(auxZonaF,utn_toLowerWord(auxZona));
                }
                if(reintentos != 3)
                {
                    afCant = atoi(auxAfCant);
                    pAfiche[indice].idCliente = id;
                    strcpy(pAfiche[indice].estado,"a cobrar");
                    pAfiche[indice].afichesCant = afCant;
                    pAfiche[indice].id = af_getNextId();
                    pAfiche[indice].isEmpty = 0;
                    strncpy(pAfiche[indice].nombreArch,auxNbrArch,51);
                    strcpy(pAfiche[indice].zona,auxZonaF);
                    printf("\nID de la venta: %d\n",pAfiche[indice].id);
                }
            }
            else
            {
                printf("Error.");
            }
        }
    }

    return retorno;
}

int af_ingresoForzado(eAfiche*,int,int,int,char*,char*)
{
    int aux;
    aux = af_devolverIndice(pBuffer,limite);
    strcpy(pBuffer[aux].nombre,nombre);
    strcpy(pBuffer[aux].
    pBuffer[aux].id = af_getNextId();
    pBuffer[aux].isEmpty = 0;

    return 0;
}
