#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include "afiches.h"
#include "clientes.h"
#include "utn.h"
#include "informes.h"
#define CL_CANT 100
#define AF_CANT 1000

int main()
{
    eCliente clientes[CL_CANT];
    eAfiche afiches[AF_CANT];
    int indice;
    int opcion;
  //  int flagg = 1;
  //  int af_flagg = 1;
    cl_initCliente(clientes,CL_CANT);
    af_initAfiches(afiches,AF_CANT);
    cl_ingresoForzado(clientes,CL_CANT,"Catalina","3J15F442","Sandoval");
    cl_ingresoForzado(clientes,CL_CANT,"Fernanda","14T769W2","Mar");
    cl_ingresoForzado(clientes,CL_CANT,"Analia","47T76852","Mar");
    cl_ingresoForzado(clientes,CL_CANT,"Diego","94B76HW0","Yarou");
    cl_ingresoForzado(clientes,CL_CANT,"Melina","61T869V1","Trindem");
    af_ingresoForzado(afiches,AF_CANT,1,4,"afichef.png","caba");
    af_ingresoForzado(afiches,AF_CANT,1,8,"afiche.jpg","zona sur");
    af_ingresoForzado(afiches,AF_CANT,2,5,"imagen.jpg","zona oeste");
    af_ingresoForzado(afiches,AF_CANT,2,9,"imafeg.jpg","caba");
    af_ingresoForzado(afiches,AF_CANT,4,11,"imag.jpg","zona oeste");
    af_ingresoForzado(afiches,AF_CANT,2,4,"arch.jpg","zona oeste");
    af_ingresoForzado(afiches,AF_CANT,3,20,"public.jpg","zona sur");
    af_ingresoForzado(afiches,AF_CANT,2,1,"bin.jpg","zona sur");
    af_ingresoForzado(afiches,AF_CANT,5,6,"codeblocks.jpg","zona oeste");


    do
    {
        printf("1)Cliente. \n2)Modificar cliente.\n3)Baja cliente. \n4)Vender afiches.\n5)Editar Venta\n6)Cobrar venta\n7)Imprimir Clientes\n8)Informar\n9)Salir.\n");
        scanf("%d",&opcion);

        switch(opcion)
        {
            case 1:
                /*if (flagg == 1)
                {
                    flagg = cl_initCliente(clientes,CL_CANT);
                }*/
                indice = devolverIndice(clientes,CL_CANT);
                if (indice != -1)
                {
                    if(cl_altaCliente(clientes,CL_CANT,indice) == 0)
                    {
                        printf("\nAlta exitosa.");
                    }
                    else
                    {
                        printf("\nError.");
                    }
                }
                else
                {
                    printf("No queda espacio disponible.");
                }
            break;

            case 2:
               // if (flagg == 0)
               // {
                    if(cl_modificarCliente(clientes,CL_CANT) == 0)
                    {
                        printf("Modificacion exitosa.");
                    }
                    else
                    {
                        printf("Error.");
                    }
               /* }

                else
                {
                    printf("No hay empleados en el sistema.");
                }*/
            break;

            case 3:
               // if (flagg == 0)
               // {
                    if(bajaClienteYVentas(clientes,afiches,CL_CANT,AF_CANT)==0)
                    {
                        printf("Baja exitosa.");
                    }
                //}

                /*else
                {
                    printf("No hay empleados en el sistema.");
                }*/
            break;

            case 4:
                af_altaAfiche(clientes,afiches,CL_CANT,AF_CANT);
            break;

            case 5:
                af_modificarVenta(afiches,AF_CANT);
                break;
            case 6:
                af_cobrarVenta(afiches,AF_CANT);

            case 7:
               // if (flagg == 0)
               // {
                    if(printClientes(clientes,afiches,CL_CANT,AF_CANT) != 0)
                    {
                        printf("\nError.");
                    }
               // }
               /* else
                {
                    printf("No hay empleados en el sistema");
                }*/

            break;

            case 8:
                informar(clientes,afiches,CL_CANT,AF_CANT);
            break;

            case 9:
                printf("Saliendo.");
            break;

            default:
            printf("Opcion invalida.");
            break;
        }
        __fpurge(stdin);//para limpiar el buffer.
        printf("\nIngrese ENTER para continuar");
        getchar(); //te freeza hasta que apretas una letra.
        system("clear"); //limpia la pantalla

    }while(opcion!=9);
    return 0;
}
