#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include "afiches.h"
#include "utn.h"
#define CL_CANT 100
#define AF_CANT 1000

int main()
{
    eCliente clientes[CL_CANT];
    eAfiche afiches[AF_CANT];
    int indice;
    int opcion;
  //  int flagg = 1;
    int af_flagg = 1;
    cl_initCliente(clientes,CL_CANT);
    cl_ingresoForzado(clientes,CL_CANT,"Catalina","3J15F442","Sandoval");
    cl_ingresoForzado(clientes,CL_CANT,"Fernanda","14T769W2","Mar");
   // af_ingresoForzado(clientes,afiches,CL_CANT,AF_CANT,"1","4","vidaf.mp4","caba");
   // af_ingresoForzado(clientes,afiches,CL_CANT,AF_CANT,"1","8","vidof.amv","zona sur");
   // af_ingresoForzado(afiches,AF_CANT,"2","5","video.mp5","zona oeste");


    do
    {
        printf("1)Cliente. \n2)Modificar cliente.\n3)Baja cliente. \n4)Vender afiches.\n5)Editar Venta\n6)Cobrar venta\n7)Imprimir Clientes\n8)Salir.\n");
        scanf("%d",&opcion);

        switch(opcion)
        {
            case 1:
                /*if (flagg == 1)
                {
                    flagg = cl_initCliente(clientes,CL_CANT);
                }*/
                indice = devolverIndice(clientes,CL_CANT);
                if (indice != -1)
                {
                    if(cl_altaCliente(clientes,CL_CANT,indice) == 0)
                    {
                        printf("\nAlta exitosa.");
                    }
                    else
                    {
                        printf("\nError.");
                    }
                }
                else
                {
                    printf("No queda espacio disponible.");
                }
            break;

            case 2:
               // if (flagg == 0)
               // {
                    if(cl_modificarCliente(clientes,CL_CANT) == 0)
                    {
                        printf("Modificacion exitosa.");
                    }
                    else
                    {
                        printf("Error.");
                    }
               /* }

                else
                {
                    printf("No hay empleados en el sistema.");
                }*/
            break;

            case 3:
               // if (flagg == 0)
               // {
                    if(cl_bajaCliente(clientes,CL_CANT,indice)==0)
                    {
                        printf("Baja exitosa.");
                    }
                //}

                /*else
                {
                    printf("No hay empleados en el sistema.");
                }*/
            break;

            case 4:
                if (af_flagg == 1)
                {
                    af_flagg = af_initAfiches(afiches,AF_CANT);
                }

            break;

            case 7:
               // if (flagg == 0)
               // {
                    if(cl_printClientes(clientes,CL_CANT) != 0)
                    {
                        printf("\nError.");
                    }
               // }
               /* else
                {
                    printf("No hay empleados en el sistema");
                }*/

            break;

            case 8:
                printf("Saliendo.");
            break;

            default:
            printf("Opcion invalida.");
            break;
        }

        __fpurge(stdin);//para limpiar el buffer.
        printf("\nIngrese ENTER para continuar");
        getchar(); //te freeza hasta que apretas una letra.
        system("clear"); //limpia la pantalla

    }while(opcion!=8);
    return 0;
}
