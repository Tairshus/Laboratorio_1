#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "utn.h"
#include "pantalla.h"
#include "contrataciones.h"
typedef struct {
    int idCliente;
    char cuit[10];
    int isEmpty;
}Cliente;

int cliente_construir(Cliente* pBuffer,int limiteCliente,
                              Contratacion* pContrataciones, int limiteContrataciones);
int con_imprimirClientes(Cliente* pBuffer,int limite);
Cliente* cliente_getClienteByCuit(Cliente* pBuffer,int limite,int upOrDonw);
