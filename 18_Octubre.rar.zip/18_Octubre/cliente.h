#ifndef CLIENTE_H_INCLUDED
#define CLIENTE_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    char nombre[64];
    char apellido[64];
    int id;
}Cliente;

Cliente* cli_newCliente(void);
int cli_setNombre(Cliente* aux,char* nombre);
int cli_setApellido(Cliente* aux,char* apellido);
int cli_getNombre(Cliente* this,char* nom);

int cli_inicializarArray(Cliente* arrayClientes[],int len);
int cli_buscarLugarVacio(Cliente* array[],int len);
int cli_buscarPorId(Cliente* array[],int len,int id);
int cli_deleteCliente(Cliente* this);

Cliente* cli_newClienteParametros(char* nom,char* app,int id);
#endif // CLIENTE_H_INCLUDED
