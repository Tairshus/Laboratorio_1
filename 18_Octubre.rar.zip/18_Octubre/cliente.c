#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cliente.h"

static int isValidNombre(char*);

Cliente* cli_newCliente(void)
{
    //return (Cliente*)malloc(sizeof(Cliente));

    Cliente* p;

    p = (Cliente*)malloc(sizeof(Cliente));

    return p;
}

int cli_setNombre(Cliente* this,char* nombre)
{
    int retorno = -1;

    if (this != NULL && isValidNombre(nombre))
    {
        strncpy(this->nombre,nombre,sizeof(this->nombre));
        retorno = 0;
    }

    return retorno;
}

int cli_setApellido(Cliente* this,char* apellido)
{
    int retorno = -1;

    if (this != NULL && isValidNombre(apellido))
    {
        strncpy(this->apellido,apellido,sizeof(this->apellido));
        retorno = 0;
    }

    return retorno;
}

static int isValidNombre(char* nombre)
{
    return 1;
}

int cli_getNombre(Cliente* this,char* nom)
{
    int retorno = -1;

    if(this != NULL && nom != NULL)
    {
        strncpy(nom,this->nombre,sizeof(this->nombre));
        retorno = 0;
    }

    return retorno;
}

int cli_buscarLugarVacio(Cliente* array[],int len)
{
    int i;
    int ret = -1;

    if(array != NULL && len > 0)
    {
        for(i=0;i<len;i++)
        {
            if(array[i]==NULL)
            {
                ret = i;
                break;
            }
        }
    }
    return ret;
}

int cli_inicializarArray(Cliente* arrayClientes[],int len)
{
    int ret = -1;
    int i;
    if(arrayClientes != NULL)
    {
        ret=0;
        for(i=0;i<len;i++)
        {
            arrayClientes[i] = NULL;
        }
    }
    return ret;
}

int cli_buscarPorId(Cliente* array[],int len,int id)
{
    int ret = -1;
    int i;
    Cliente* aux;

    for(i=0;i<len;i++)
    {
        aux = array[i];
        if(aux != NULL && aux->id == id)
        {
            ret = i;
            break;
        }
    }

    return ret;
}

int cli_deleteCliente(Cliente* this)
{
    int ret = -1;
    if(this != NULL)
    {
        free((void*)this);
        ret = 0;
    }
    return ret;
}

Cliente* cli_newClienteParametros(char* nom,char* app,int id)
{
    Cliente* p;
    p = cli_newCliente();
    if(p != NULL)
    {
        if(setNombre(p,nom) == -1 || setApellido(p,app) == -1 || setId(p,id) == -1)
        {
            cli_deleteCliente(p);
            p=NULL;
        }
    }
    return p;
}
Cliente* newCliente(void)
