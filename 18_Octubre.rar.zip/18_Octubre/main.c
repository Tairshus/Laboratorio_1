#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cliente.h"
#define CLIENTES 100

/*
int funcion(void)
{
    return 7;
}
void funcionRecibeF(int (*pepe)(void))
{
    pepe();
    printf("Puntero desde funciona: %p\n",pepe);
    printf("Pepe devuelve: %p\n",pepe());
}

int main()
{
    printf("%p\n",funcion);
    funcionRecibeF(funcion);

    return 0;
}
*/
int main()
{
    Cliente* aux;
    Cliente* arrayClientes[CLIENTES];
    char nombreAux[64];
    int indexVacio;

    cli_inicializarArray(arrayClientes,CLIENTES);


    aux = newCliente();
    indexVacio = cli_buscarLugarVacio(arrayClientes,CLIENTES);

    if(aux != NULL && indexVacio >= 0)
    {
        //printf("size: %d",sizeof(aux->nombre));   //En lugar de escribir 64 escribo eso
        cli_setNombre(aux,"Raul");
        cli_setApellido(aux,"Restart");
        arrayClientes[0] = aux;

        cli_getNombre(aux,nombreAux);
        printf("%s",nombreAux);
    }

    return 0;
}
