#include "LinkedList.h"
#include "Empleado.h"
#include <string.h>
#include <stdio.h>

int parser_parseEmpleados(char* fileName, LinkedList* listaEmpleados)
{
    FILE* pFile;
    pFile = fopen(fileName,"r");

    int returnAux = -1;
    char* p;
    const char* delim=",";
    char* id;
    char* nombre;
    char* horas;
    char line[1024];

    // salteo primer linea
    fgets(line,1024,pFile);

    while(1)
    {
        // leo linea
        p = fgets(line,128,pFile);
        if(p==NULL)
        break;
        printf("%s",line);

            // creo empleado
        Empleado* auxE;

        // obtengo partes y las cargo
        id = strtok(line,delim);
        nombre = strtok(NULL,delim);
        horas = strtok(NULL,delim);

        auxE = Empleado_newConParametros(nombre,id,horas);

        if(auxE != NULL)
        {
            ll_add(listaEmpleados,auxE);
            returnAux = 1;
        }
    }
    return returnAux;
}
