#include "LinkedList.h"
#include "Compra.h"
#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>

int parser_parseCompras(char* fileName, LinkedList* lista)
{
    FILE* pFile;
    pFile = fopen(fileName,"r");

    int returnAux = -1;
    char* p;
    const char* delim=","; //nombre id precio unidad iva
    char* id;
    char* nombre;
    char* precio;
    char* unidad;
    char* iva;
    char line[1024];

    // salteo primer linea
    fgets(line,1024,pFile);

    while(1)
    {
        // leo linea
        p = fgets(line,1024,pFile);
        if(p==NULL)
        break;
        //printf("%s",line);

            // creo empleado
        S_Compra* auxCompra;


        // obtengo partes y las cargo
        nombre = strtok(line,delim);
        id = strtok(NULL,delim);
        precio = strtok(NULL,delim);
        unidad = strtok(NULL,delim);
        iva = strtok(NULL,delim);

        auxCompra = Compra_newConParametros(nombre,id,unidad,precio,iva);

        if(auxCompra != NULL)
        {
            ll_add(lista,auxCompra);
            returnAux = 1;
        }
    }
    fclose(pFile);
    return returnAux;
}

