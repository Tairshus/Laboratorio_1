typedef struct
    {
        char nombre[50];
        char descripcion[200];
        float precio;
        int isEmpty;
        int id;
    } producto;

int recibeDatos(producto array[],int len,int indice);

void inicializarIsEmpty(producto array[],int tamanio);

void mostrarArray(producto array[],int tamanio);

void mostrarArrayIndice(producto array[],int indice);

int devolverIndice(producto array[],int tamanio);

void modificarProducto(producto array[],int tamanio,int id);

int devolverIndiceProducto(producto array[],int tamanio);

void borrarProducto(producto array[],int tamanio,int id);
