#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include "utn.h"
#include "productos.h"
#define CANTIDAD 50

/*
1)  Definir un tipo de dato que represente un producto.
    El producto tiene un nombre, una descripcion y un precio
2)  Definir un array de 200 productos, indicar de alguna manera
    que la info de cada item no esta cargada.
3)  Realizar una funcion que reciba el array, un indice, y le
    permita al usuario cargar los datos en el item de la posicion especificada por el indice.
4)  Realizar una funcion que reciba el array y un indice e imprima
    los datos del item de la posicion especificada por el indice.
5)  Realizar una funcion que me devuelva el indice de un item vacio (sin cargar).
6) Realizar un programa con un menu de dos opciones:
    a) Cargar un producto
    b) Imprimir lista productos
7)  Agregar al tipo de dato el campo ID que represente un identificador unico.
    Modificar el codigo anterior para que el ID se genere automaticamente. Se debera cargar el ID automaticamente al cargar un producto, y se debera imprimir al imprimir la lista.
8)  Realizar una funcion que reciba el array y un ID, y me devuelva el indice
    del item con dicho ID.
9)  Realizar una funcion que reciba el array, un indice, y le permita al usuario
    modificar los campos nombre y precio del item del array en la posicion especificada por el indice.
10)  Agregar una opcion en el menu. "Editar producto" que pida al usuario el ID del
    mismo y le permita cambiar el nombre y el precio.
11)  Agregar una opcion en el menu "Borrar producto" que pida al usuario el ID del
    mismo.
*/

int main()
{

    producto arrayProductos[200];
    inicializarIsEmpty(arrayProductos,200);
    int indice;
    int opcion;

    do
    {
        printf("1. Cargar Productos \n2. Imprimir lista de productos\n3. Modificar Producto \n4.Salir\n");
        scanf("%d",&opcion);

        switch(opcion)
        {
            case 1:
            indice = devolverIndice(arrayProductos,200);
            if (indice != -1)
            {
                recibeDatos(arrayProductos,200,indice);
            }
            else
            {
                printf("No queda espacio disponible... por ahora.");
            }
            break;

            case 2:
            mostrarArray(arrayProductos,200);
            break;

            case 3:
            indice = devolverIndiceProducto(arrayProductos,200);
            if(indice != -1)
            {
                modificarProducto(arrayProductos,200,indice);
            }
            else
            {
                printf("ID invalido.");
            }

            break;

            case 4:
            printf("Saliendo.");
            break;

            default:
            printf("Opcion invalida.");
            break;
        }

        __fpurge(stdin);//para limpiar el buffer.
        printf("\nIngrese ENTER para continuar");
        getchar(); //te freeza hasta que apretas una letra.
        system("clear"); //limpia la pantalla

    }while(opcion!=4);
}
