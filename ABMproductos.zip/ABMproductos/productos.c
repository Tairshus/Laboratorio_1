#include <stdio_ext.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "utn.h"

typedef struct
    {
        char nombre[50];
        char descripcion[200];
        float precio;
        int isEmpty;
        int id;
    } producto;

void inicializarIsEmpty(producto array[],int tamanio)
{
    int i;
    for(i=0;i<tamanio;i++)
    {
        array[i].isEmpty=1;
    }
}


int recibeDatos(producto array[],int len,int indice)
{
__fpurge(stdin);
char auxNombre[50];
char auxDescripcion[200];
char validarPrecio[20];
float auxPrecio;

int retorno=0;
if(array!=NULL && len>0 && indice>=0 && indice<len)
{
    if(!utn_getNombre(auxNombre,50,"\nNombre producto: ","\nInvalido",2) &&
    !utn_getNombre(auxDescripcion,200,"\nDescripcion producto: ","\nInvalido",2) &&
    !utn_getSoloFloat(validarPrecio, 20,"Precio: ","Invalido.",2))
    {
       strncpy(array[indice].nombre,auxNombre,50);
       strncpy(array[indice].descripcion,auxDescripcion,200);
       auxPrecio = atof(validarPrecio);
       array[indice].precio=auxPrecio;
       array[indice].isEmpty=0;
       array[indice].id = indice+1;
    }

}
return retorno;
}

void mostrarArray(producto array[],int tamanio)
{
    int i;
    for(i=0;i<tamanio;i++)
    {
        if(array[i].isEmpty==0)
        {
            printf("\nID de Producto: %d",array[i].id);
            printf("\nNombre: %s ",array[i].nombre);
            printf("\nDescripcion: %s",array[i].descripcion);
            printf("\nPrecio: %.2f\n",array[i].precio);
        }
    }
}

void mostrarArrayIndice(producto array[],int indice)
{

    if(array[indice].isEmpty==0)
    {
        printf("\nNombre: %s ",array[indice].nombre);
        printf("\nDescripcion: %s",array[indice].descripcion);
        printf("\nPrecio: %f",array[indice].precio);
    }
}

int devolverIndice(producto array[],int tamanio)
{
    int retorno=-1;
    int i;

    for(i=0;i<tamanio;i++)
    {
        if(array[i].isEmpty)
        {
            retorno=i;
            break;
        }
    }
    return retorno;
}

int devolverIndiceProducto(producto array[],int tamanio)
{
    int id =-1;
    char auxId[tamanio];

    printf("Ingrese id de Producto.");
    scanf("%s",auxId);
    if(isValidInt(auxId,tamanio))
    {
        id = atoi(auxId);
    }

    return id-1;
}

void modificarProducto(producto array[],int len,int id)
{
__fpurge(stdin);
char auxNombre[50];
char auxDescripcion[200];
char validarPrecio[20];
float auxPrecio;

if(array!=NULL && len>0 && id>=0 && id<len && array[id].isEmpty != 1)
{
    if(!utn_getNombre(auxNombre,50,"\nNombre producto: ","\nInvalido",2) &&
    !utn_getNombre(auxDescripcion,200,"\nDescripcion producto: ","\nInvalido",2) &&
    !utn_getSoloFloat(validarPrecio, 20,"Precio: ","Invalido.",2))
    {
       strncpy(array[id].nombre,auxNombre,50);
       strncpy(array[id].descripcion,auxDescripcion,200);
       auxPrecio = atof(validarPrecio);
       array[id].precio=auxPrecio;
    }

}
    else
    {
    printf("ID invalido");
    }
}

void borrarProducto(producto array[],int tamanio,int id)
{

if (array !=NULL && id >=0 && id < tamanio && array[id].isEmpty == 0)
{
printf("\nEl producto seleccionado es:");

}

}

void mostrarProducto(producto array[],int tamanio,int id)
{
int i;
    for(i=0;i<tamanio,i++) //TERMINAR
    {

    }
}
