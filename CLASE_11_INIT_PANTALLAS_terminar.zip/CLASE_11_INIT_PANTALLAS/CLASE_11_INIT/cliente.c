#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include "utn.h"
#include "cliente.h"

static int getNextId();

int cliente_construir(  Cliente* pCliente,int limiteCliente,
                        Contratacion* pContrataciones,int limiteContrataciones)
{

    int retorno = -1;
    int i;
    int idCliente = 0;
    if( pCliente != NULL && limiteCliente > 0 &&
        pContrataciones != NULL && limiteContrataciones > 0)
    {
        for(i=0;i<limiteCliente;i++)
        {
            pCliente[i].isEmpty = 1;
        }
        for(i=0;i<limiteContrataciones;i++)
        {

            if(cliente_getClienteByCuit(pCliente,limiteCliente,pContrataciones[i].cuit) == NULL)
            {
                strncpy(pCliente[idCliente].cuit,pContrataciones[i].cuit,10);
                pCliente[idCliente].isEmpty = 0;
                pCliente[idCliente].idCliente = getNextId();
                idCliente = idCliente +1;
            }
        }
        retorno = 0;
    }
    return retorno;
}



Cliente* cliente_getClienteByCuit(Cliente* pBuffer,int limite, char* cuit)
{
    Cliente* retorno = NULL;
    int i;
    if(pBuffer != NULL && limite > 0 && cuit != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(pBuffer[i].isEmpty==0 && strcmp(cuit,pBuffer[i].cuit)==0)
            {
                retorno = &pBuffer[i];// pBuffer+i;
                break;
            }
        }
    }
    return retorno;
}


static int getNextId()
{
    static int idCliente = 0;
    idCliente++;
    return idCliente;
}


int cliente_imprimirClientes(Cliente* pBuffer,int limite)
{
    int retorno = -1;
    int i;
    if(pBuffer != NULL && limite > 0)
    {
        for(i=0;i<limite;i++)
        {
            if(pBuffer[i].isEmpty == 0)
            {
                printf("\nCUIT: %s",pBuffer[i].cuit);
                printf("\nisEmpty: %d",pBuffer[i].isEmpty);
                printf("\nID: %d",pBuffer[i].idCliente);
            }
        }
        retorno = 0;
    }
    return retorno;
}


int cliente_ordenarByCuit(Cliente* pBuffer,int limite,int upOrDown)
{

    int retorno = -1;

    if(pBuffer != NULL && limite > 0)
    {
        Cliente auxCliente;
        int i,j;
        for(i=0;i<limite-1;i++)
        {

            for(j=i+1;j<limite;i++)
            {
                if(upOrDown == 0 && strcmp(pBuffer[i].cuit,pBuffer[j].cuit) > 0)
                {
                    auxCliente = pBuffer[j];
                    pBuffer[j] = pBuffer[i];
                    pBuffer[i] = auxCliente;
                    break;
                }

                if(upOrDown == 1 && strcmp(pBuffer[i].cuit,pBuffer[j].cuit) < 0)
                {
                    auxCliente = pBuffer[j];
                    pBuffer[j] = pBuffer[i];
                    pBuffer[i] = auxCliente;
                    break;
                }
            }
        }
    retorno = 0;
    }
    return retorno;
}
