int utn_getNumero(int*,char*,char*,int,int,int);
int getInt(int*);
int utn_getCaracter(char*,char*,char*,int);

