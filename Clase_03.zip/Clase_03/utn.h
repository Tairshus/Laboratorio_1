int utn_getNumero(int*,char*,char*,int,int,int);
int getInt(int*);
int get_Caracter(  char* pResultado,
                   char* mensaje,
                   char* mensajeError,
                   int minimo,
                   int maximo,
                   int reintentos);

