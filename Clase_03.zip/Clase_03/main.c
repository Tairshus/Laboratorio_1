#include <stdio_ext.h>
#include <stdlib.h>
#include "utn.h"



int main()
{
    char caracter;

    printf("\E[0;32m");

   /*int numero;
    if(utn_getNumero(&numero,"NUMERO?","Fuera de Rango",10,100,2)==0)
    {
        printf("\nEl numero es %d\n",numero);
    }
    else
    {
        printf("Se acabaron los intentos.\n\n");
    }*/

    if(utn_getCaracter(&caracter,"Caracter: ","Caracter invalido",2)==0)
    {
        printf("\nEl caracter es: %c",caracter);
    }
    else
    {
        printf("Se acabaron los intentos.\n\n");
    }
    printf("\E[00m");
    return 0;
}
