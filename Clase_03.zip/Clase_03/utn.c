#include <stdio_ext.h>
#include <stdlib.h>
#include "utn.h"
/**
* \brief
* \param pResultado Puntero a la variable resultado
* \param mensaje Es el mensaje a ser mostrado
* \param mensajeError Es el mensaje a ser mostrado en caso de error
* \param minimo El valor minimo que sera aceptado
* \param maximo El valor maximo que sera aceptado
* \param reintentos Numero de veces que puede intentar el usuario ingresar un numero correcto
* \return Retorna "0" en caso de que el numero sea valido y "-1" en caso de error
*/
int utn_getNumero (    int* pResultado,
                   char* mensaje,
                   char* mensajeError,
                   int minimo,
                   int maximo,
                   int reintentos)
{
    int number;
    do
    {
        printf("%s",mensaje);
        __fpurge(stdin);
        if(getInt(&number)==1)
        {
            if(number >= minimo && number <= maximo)
            {
                *pResultado = number;
                break;
            }
            else
            {
                printf("%s\n",mensajeError);
                reintentos--;
            }
        }
        else
        {
            reintentos--;
        }
    }while(reintentos>0);

    if (pResultado==NULL || reintentos==0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int getInt(int* pResultado)
{
    char buffer[64];
    scanf("%s",buffer);
    *pResultado = atoi(buffer);
    return -1;
}

int get_Caracter(  char* pResultado,
                   char* mensaje,
                   char* mensajeError,
                   int minimo,
                   int maximo,
                   int reintentos)
{
return 0;
}

