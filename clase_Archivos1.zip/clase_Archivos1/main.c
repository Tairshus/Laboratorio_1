#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cliente.h"
#define CLIENTES 1000

int main()
{
/*
id,first_name,last_name,is_empty
1,Eric,Knight,false
*/
    FILE*pArchivo = fopen("data.csv","r");
    Cliente* arrayClientes[CLIENTES];
    Cliente* aux;

    cli_inicializarArray(arrayClientes,CLIENTES);
    //FILE*pArchivoBkp = fopen("dataBkp.csv","w");

    //char buffer[4096];

    char bufferId[1024];
    char bufferNombre[1024];
    char bufferApellido[1024];
    char bufferIsEmpty[1024];
    int indexVacio;

    if(pArchivo != NULL)
    {
        //fscanf(pArchivo,"%s\n",buffer);
        //printf("%s",buffer);  descarto la primer linea

        while(feof(pArchivo) == 0)
        {
        fscanf(pArchivo,"%[^,],%[^,],%[^,],%[^\n]\n",
                        bufferId,
                            bufferNombre,
                                bufferApellido,
                                    bufferIsEmpty);
        //fprintf(pArchivoBkp,"%s\n",buffer);

        /*
        printf("\n%s-%s-%s-%s",bufferId,
                               bufferNombre,
                               bufferApellido,
                               bufferIsEmpty);*/

        cli_newClienteParametros(bufferNombre,bufferApellido,bufferId);

        indexVacio = cli_buscarLugarVacio(arrayClientes,CLIENTES);

        cli_setNombre(arrayClientes[indexVacio],bufferNombre);
        }
        fclose(pArchivo);
        //fclose(pArchivoBkp);
    }
    else
    {
        printf("\nError, no existe!!!");
    }

    return 0;
}









/*
int main()
{
    int cantidadEscrita , longitudTexto;
    FILE *pArchivo;

    char texto[ ] = "hola mundo!!!";

    pArchivo = fopen("banco.txt","w");

    if (pArchivo == NULL)
    {
        printf("\nError de Apertura");
        exit(1);
    }

    longitudTexto = strlen (texto);
    cantidadEscrita = fwrite(texto ,sizeof (char), longitudTexto , pArchivo );


    cantidadLeida = fread(texto ,sizeof (char), longitudTexto , pArchivo );
    printf(“El texto leido es: %s”, texto) ;
    */
  /*  if (cantidadEscrita<longitudTexto)
        printf("\nError al escribir el archivo");

    fclose(pArchivo);

    return 0;
}*/

/*
do()
{
    cantidadLeida = fread(texto ,sizeof (Empanada), 1 , pArchivo );
}while(cantidadLeida != 1)
*/
