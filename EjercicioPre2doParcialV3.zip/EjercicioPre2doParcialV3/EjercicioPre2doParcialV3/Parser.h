#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

#include "LinkedList.h"

int parser_parseCompras(char* fileName, LinkedList* lista);


#endif // PARSER_H_INCLUDED
