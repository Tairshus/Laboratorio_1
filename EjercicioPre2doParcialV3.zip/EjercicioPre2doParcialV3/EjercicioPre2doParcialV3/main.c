#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include "Compra.h"
#include "LinkedList.h"
#include "Parser.h"
#define BUFFER_STR 1024

/**
    Realizar un programa que lee de un archivo los datos de compras de productos realizadas por clientes.
    Luego se le pedira al usuario que ingrese un id de un producto y el programa deber� imprimir por pantalla:
    - 1. Lista de compras filtrada segun el producto ingresado
    - 2. Monto total de cada compra considerando el valor del iva indicado.

    - 3. Por ultimo la lista filtrada obtenida con los datos ya calculados, debera ser escrita en un archivo separado por
    comas llamado "informe.csv", con el mismo formato que el original pero con una columna mas al final, en donde se
    indicara el monto total calculado.

    Para realizar el punto 1, se debera utilizar la funcion "filter".
    Para realizar el punto 2, se debera utilizar la funcion "map".
    Para imprimir por pantalla la lista, utilizar iterator.
*/

int utn_getSoloInt(char* pInt, int limite, char* msg,char* msgErr, int reintentos);
int isValidInt(char* pBuffer,int limite);
int filtrarPorId(void* pElement,void* id);

int generarArchivoInforme(char* fileName,LinkedList* listaCompras);

int main()
{
    char id[10];
    // Definir lista de compras
    LinkedList* listaCompras;
    LinkedList* listaFiltrada;



    // Crear lista compras
    //...
    listaCompras = ll_newLinkedList();
    listaFiltrada = ll_newLinkedList();
    // Leer compras de archivo data.csv
    if(parser_parseCompras("data.csv",listaCompras)==1)
    {
        // Filtrar
        if(!utn_getSoloInt(id,10,"Ingrese ID de producto: ","Error.",2))
        {
            listaFiltrada = ll_filter(listaCompras,filtrarPorId,id);
            printf("\nFILTRADA: %d\n",ll_len(listaFiltrada));
        }
        //TODO

        // Calcular montos
        printf("Calculando montos totales...\n");
        //TODO

        // Generar archivo de salida
        if(generarArchivoInforme("informe.csv",listaFiltrada)==1)
        {
            printf("Archivo generado correctamente\n");
        }
        else
            printf("Error generando archivo\n");
    }
    else
        printf("Error leyendo compras\n");


    return 0;
}

int generarArchivoInforme(char* fileName,LinkedList* listaFiltrada)
{
    int returnAux = -1;
    FILE* pFile=fopen(fileName,"w");
    S_Compra* pCompra;
    int auxId;
    float auxPrecio;
    int auxUnidad;
    float auxIva;
    char nombre[1024];
    int i;

    if(pFile != NULL && listaFiltrada !=NULL)
    {
        fprintf(pFile,"nombreCliente,idProducto,precioUnitario,unidades,iva\n");
        for(i=0;i<ll_len(listaFiltrada);i++)
        {
            pCompra=ll_get(listaFiltrada,i);
            Compra_getNombreCliente(pCompra,nombre);
            Compra_getIdProducto(pCompra,&auxId);
            Compra_getIva(pCompra,&auxIva);
            Compra_getUnidades(pCompra,&auxUnidad);
            Compra_getPrecioUnitario(pCompra,&auxPrecio);
            fprintf(pFile,"%s,%d,%.2f,%d,%.2f\n",nombre,auxId,auxPrecio,auxUnidad,auxIva);
        }
        returnAux = 1;
    }
    else
    {
        printf("\nNo hay una lista de empleados cargada.\n");
    }
    fclose(pFile);

    return returnAux;
}


static int getString(char* pBuffer, int limite)
{
    int retorno = 1;
    char bufferStr[BUFFER_STR];
    int len;
    if(pBuffer != NULL && limite > 0)
    {
        __fpurge(stdin);
        fgets(bufferStr,limite,stdin);
        len = strlen(bufferStr);
        if(len != limite-1 ||  bufferStr[limite-2] == '\n')
        {
            bufferStr[len-1] = '\0';
        }
        retorno = 0;
        strncpy(pBuffer,bufferStr,limite);
    }
    return retorno;
}

int isValidInt(char* pBuffer,int limite)
{
    int retorno = 0;
    int i;
    if(pBuffer != NULL && limite > 0)
    {
        retorno = 1;
        for(i=0;i < limite && pBuffer[i] != '\0';i++)
        {
            if(pBuffer[i] < '0' || pBuffer[i] > '9')
            {
                retorno = 0;
                break;
            }
        }
    }
    return retorno;
}

int utn_getSoloInt(  char* pInt, int limite, char* msg,
                    char* msgErr, int reintentos)

{
    int retorno=1;
    char bufferInt[BUFFER_STR];

    if( pInt != NULL && limite > 0 && msg != NULL &&
        msgErr != NULL && reintentos >= 0)
    {
        do
        {
            reintentos--;
            printf("%s",msg);
            if( getString(bufferInt,limite) == 0 &&
                isValidInt(bufferInt,limite))
            {
                strncpy(pInt,bufferInt,limite);
                retorno = 0;
                break;
            }
            else
            {
                printf("%s",msgErr);
            }
        }while(reintentos >= 0);
    }
    return retorno;
}

int filtrarPorId(void* pElement,void* id)
{
    int returnAux = -1;
    int tID;

    if(pElement != NULL && id != NULL)
    {
        S_Compra* auxCompra;
        auxCompra = pElement;
        tID = atoi(id);

        if(auxCompra->idProducto == tID)
        {
            returnAux = 0;
        }
    }
    return returnAux;
}
