#ifndef COMPRA_H_INCLUDED
#define COMPRA_H_INCLUDED

typedef struct
{
  char nombreCliente[128];
  int idProducto;
  int unidades;
  float precioUnitario;
  float iva;
  float montoTotal;
}S_Compra;

void com_calcularMonto(void* p);

S_Compra* Compra_new();
void Compra_delete();
S_Compra* Compra_newConParametros(char* nombreCliente,char* idProducto,char* unidades,char* precioUnitario,char* iva);

int Compra_setNombreCliente(S_Compra* this,char* nombreCliente);
int Compra_getNombreCliente(S_Compra* this,char* nombreCliente);

int Compra_setIdProducto(S_Compra* this,int idProducto);
int Compra_getIdProducto(S_Compra* this,int* idProducto);

int Compra_setUnidades(S_Compra* this,int unidades);
int Compra_getUnidades(S_Compra* this,int* unidades);

int Compra_setPrecioUnitario(S_Compra* this,float precioUnitario);
int Compra_getPrecioUnitario(S_Compra* this,float* precioUnitario);

int Compra_setIva(S_Compra* this,float iva);
int Compra_getIva(S_Compra* this,float* iva);

int Compra_setMontoTotal(S_Compra* this,float montoTotal);
int Compra_getMontoTotal(S_Compra* this,float* montoTotal);

#endif // COMPRA_H_INCLUDED
