#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "utn.h"

#define CANTIDAD_EMPLEADOS 6

/*void ordenarPorNombre(char pNombres[][50],char pApellidos[][50],char pDni[][50],int limite)
{
    int swap;
    int i;
    char bufferStr[256];

    do
    {
        swap = 0;
        for(i=0;i<limite-1;i++)
        {
            if(strcmp(pNombres[i],pNombres[i+1])>0)
            {
                swap=1;                             //"swap" viene a ser una especie de "flagg"
                strcpy(bufferStr,pNombres[i]);
                strcpy(pNombres[i],pNombres[i+1]);
                strcpy(pNombres[i+1],bufferStr);

                strcpy(bufferStr,pApellidos[i]);
                strcpy(pApellidos[i],pApellidos[i+1]);
                strcpy(pApellidos[i+1],bufferStr);

                strcpy(bufferStr,pDni[i]);
                strcpy(pDni[i],pDni[i+1]);
                strcpy(pDni[i+1],bufferStr);
            }
        }

    }while(swap);

}
*/

typedef struct sEmpleado //Pones el sEmpleado es opcional, funciona igual
{
    char nombre[50];
    char apellido[50];
    float salario;
    struct sEmpleado* pNode //Declarar la estructura sirve para declarar un puntero dentro
}eEmpleado;

// Empleao arrayEmpleados[CANTIDAD_EMPLEADOS];
//strcpy(arrayEmpleados[1].apellido,"LOPEZ"); copiar string
/**
CASO DE PUNTERO
Empleado* pEmpleado;
pEmpleado = arrayEmpleados;
strcpy((pEmpleado+1)->apellido,"GOMEZ");
*/
void ordenarArray(char nombres[][50],int limite);

int main()
{
    char nombres[CANTIDAD_EMPLEADOS][50];
    int i;

    for(i=0;i < CANTIDAD_EMPLEADOS;i++)
    {
        utn_getNombre(nombres[i],50,"\nNombre?","Error",2);
    }

    ordenarArray(nombres,CANTIDAD_EMPLEADOS);

    for(i=0;i < CANTIDAD_EMPLEADOS;i++)
    {
        printf("%s\n",nombres[i]);
    }
    return 0;
}

void ordenarArray(char nombres[][50],int limite)
{
    int i,j;
    char auxNombre[limite];
    for(i=0;i<limite-1;i++)
    {
        for(j=i+1;j<limite;j++)
        {
            if(strcmp(nombres[i],nombres[j]) > 0)
            {
                strncpy(auxNombre,nombres[i],limite);
                strncpy(nombres[i],nombres[j],limite);
                strncpy(nombres[j],auxNombre,limite);
            }
        }
    }
}

