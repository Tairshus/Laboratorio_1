#include "venta.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utn.h"

eVenta* venta_new()
{
    eVenta* this;
    this=malloc(sizeof(eVenta));
    return this;
}

void venta_delete(eVenta* this)
{
    free(this);
}

eVenta* venta_newConParametros(char* id,char* fecha,char* codigoProducto,char* cantidad,char* precioUnitario,char* cuit)
{
    eVenta* this;
    this=venta_new();
    int valId;
    int valCantidad;
    float valPrecio;

    if(isValidStringOfData(codigoProducto,64) &&
       isValidStringOfData(fecha,64) &&
       isValidInt(id,10) &&
       isValidInt(cantidad,10) &&
       isValidFloat(precioUnitario,15) &&
       isValidCuit(cuit,20));
    {
        valId = atoi(id);
        valCantidad = atoi(cantidad);
        valPrecio = atof(precioUnitario);

        if(
        !venta_setId(this,valId)&&
        !venta_setFecha(this,fecha)&&
        !venta_setCodigoProducto(this,codigoProducto)&&
        !venta_setCantidad(this,valCantidad)&&
        !venta_setPrecioUnitario(this,valPrecio)&&
        !venta_setCuit(this,cuit))
        {
            return this;
        }
    }

    venta_delete(this);
    return NULL;
}

int venta_setId(eVenta* this,int id)
{
    int retorno=-1;
    static int proximoId=-1;

    if(this!=NULL && id==-1)
    {
        proximoId++;
        this->id=proximoId;
        retorno=0;
    }
    else if(id>proximoId)
    {
        proximoId=id;
        this->id=proximoId;
        retorno=0;
    }
    return retorno;
}

int venta_getId(eVenta* this,int* id)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *id=this->id;
        retorno=0;
    }
    return retorno;
}

int venta_setFecha(eVenta* this,char* fecha)
{
    int retorno=-1;
    if(this!=NULL && fecha!=NULL)
    {
        strcpy(this->fecha,fecha);
        retorno=0;
    }
    return retorno;
}

int venta_getFecha(eVenta* this,char* fecha)
{
    int retorno=-1;
    if(this!=NULL && fecha!=NULL)
    {
        strcpy(fecha,this->fecha);
        retorno=0;
    }
    return retorno;
}

int venta_setCodigoProducto(eVenta* this,char* codigoProducto)
{
    int retorno=-1;
    if(this!=NULL && codigoProducto!=NULL)
    {
        strcpy(this->codigoProducto,codigoProducto);
        retorno=0;
    }
    return retorno;
}

int venta_getCodigoProducto(eVenta* this,char* codigoProducto)
{
    int retorno=-1;
    if(this!=NULL && codigoProducto!=NULL)
    {
        strcpy(codigoProducto,this->codigoProducto);
        retorno=0;
    }
    return retorno;
}

int venta_setCantidad(eVenta* this,int cantidad)
{
    int retorno=-1;
    if(this!=NULL)
    {
        this->cantidad=cantidad;
        retorno=0;
    }
    return retorno;
}

int venta_getCantidad(eVenta* this,int* cantidad)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *cantidad=this->cantidad;
        retorno=0;
    }
    return retorno;
}

int venta_setPrecioUnitario(eVenta* this,float precioUnitario)
{
    int retorno=-1;
    if(this!=NULL)
    {
        this->precioUnitario=precioUnitario;
        retorno=0;
    }
    return retorno;
}

int venta_getPrecioUnitario(eVenta* this,float* precioUnitario)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *precioUnitario=this->precioUnitario;
        retorno=0;
    }
    return retorno;
}

int venta_setCuit(eVenta* this,char* cuit)
{
    int retorno=-1;
    if(this!=NULL && cuit!=NULL)
    {
        strcpy(this->cuit,cuit);
        retorno=0;
    }
    return retorno;
}

int venta_getCuit(eVenta* this,char* cuit)
{
    int retorno=-1;
    if(this!=NULL && cuit!=NULL)
    {
        strcpy(cuit,this->cuit);
        retorno=0;
    }
    return retorno;
}

/** \brief Obtiene la cantidad de ventas del elemento
* \param element void*
* \return -1 si el puntero a element es NULL | auxVenta->Cantidad si no hubo problema
*/
int venta_cantidad(void* element)
{
    int returnAux = -1;
    eVenta* auxVenta;

    if(element != NULL)
    {
        auxVenta = element;

        returnAux = auxVenta->cantidad;
    }

    return returnAux;
}

/** \brief Determina si el monto es mayor a 10000 del elemento pasado
* \param element void*
* \return -1 si el puntero a element es NULL o si el elemento no cumple con lo pedido | 1 si no hubo problema
*/
int venta_cantidadMayor1(void* element)
{
    int returnAux = -1;
    eVenta* auxVenta;

    if(element != NULL)
    {
        auxVenta = element;
        if(auxVenta->precioUnitario > 10000)
        {
            returnAux = 1;
        }
    }

    return returnAux;
}

/** \brief Determina si el monto es mayor a 20000 del elemento pasado
* \param element void*
* \return -1 si el puntero a element es NULL o si el elemento no cumple con lo pedido | 1 si no hubo problema
*/
int venta_cantidadMayor2(void* element)
{
    int returnAux = -1;
    eVenta* auxVenta;

    if(element != NULL)
    {
        auxVenta = element;
        if(auxVenta->precioUnitario > 20000)
        {
            returnAux = 1;
        }
    }

    return returnAux;
}

/** \brief Determina si el elemento pasado contiene un TV lcd
* \param element void*
* \return -1 si el puntero a element es NULL o si el elemento no es el buscado | 1 si no hubo problema
*/
int venta_cantidadTvsLcd(void* element)
{
    int returnAux = -1;
    eVenta* auxVenta;

    if(element != NULL)
    {
        auxVenta = element;
        if(!strcmp(auxVenta->codigoProducto,"LCD_TV"))
        {
            returnAux = auxVenta->cantidad;
        }
    }

    return returnAux;
}

/** \brief Genera el informe en el archivo informes.txt (modo texto).
 *
 * \param path char*
 * \param listaVentas LinkedList*
 * \return -1 si el puntero a la LinkedList es NULL o el puntero a FILE es NULL
 *
 */
int venta_saveAsText(char* path ,int cantidad,int mayor1,int mayor2,int lcd)
{
    int returnAux = -1;
    FILE* pFile=fopen(path,"w");

    if(pFile!=NULL)
    {
        fprintf(pFile,"***************\nInforme de Ventas\n***************");
        fprintf(pFile,"\n- Cantidad de unidades vendidas totales: %d",cantidad);
        fprintf(pFile,"\n- Cantidad de ventas por un monto mayor a $10000: %d",mayor1);
        fprintf(pFile,"\n- Cantidad de ventas por un monto mayor a $20000: %d",mayor2);
        fprintf(pFile,"\n- Cantidad de TVs LCD vendidas: %d",lcd);
        returnAux = 0;
    }
    fclose(pFile);

    return returnAux;
}

