#include "LinkedList.h"
#include "venta.h"
#include <string.h>
#include <stdio.h>

/** \brief Carga los datos del archivo a la LinkedList
* \param fileName char*
* \param listaVentas LinkedList*
* \return -1 si el puntero a FILE es NULL | 1 si los datos fueron cargados correctamente
*/
int parserVentas(char* fileName, LinkedList* listaVentas)
{
    FILE* pFile;
    pFile = fopen(fileName,"r");

    int returnAux = -1;
    char* p;
    const char* delim=",";
    char* id;
    char* fecha;
    char* codigo;
    char* cantidad;
    char* precio;
    char* cuit;
    char line[1024];

    fgets(line,1024,pFile);

    if(pFile != NULL)
    {
        while(1)
        {
            p = fgets(line,1024,pFile);
            if(p==NULL)
            break;

            eVenta* auxVenta;

            id = strtok(line,delim);
            fecha = strtok(NULL,delim);
            codigo = strtok(NULL,delim);
            cantidad = strtok(NULL,delim);
            precio = strtok(NULL,delim);
            cuit = strtok(NULL,delim);

            auxVenta = venta_newConParametros(id,fecha,codigo,cantidad,precio,cuit);

            if(auxVenta != NULL)
            {
                ll_add(listaVentas,auxVenta);
                returnAux = 1;
            }
        }
    }
    fclose(pFile);
    return returnAux;
}

