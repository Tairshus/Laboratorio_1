#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

#include "LinkedList.h"

int parserVentas(char* fileName, LinkedList* listaVentas);


#endif // PARSER_H_INCLUDED
