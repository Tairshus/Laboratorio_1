#include <stdio.h>
#include <stdlib.h>
#include "parser.h"
#include "LinkedList.h"
#include "venta.h"

int main()
{
    LinkedList* listaVentas = ll_newLinkedList();
    parserVentas("data.csv",listaVentas);
    int cantidad;
    int mayor1;
    int mayor2;
    int lcd;

    cantidad = ll_count(listaVentas,venta_cantidad);
    mayor1 = ll_count(listaVentas,venta_cantidadMayor1);
    mayor2 = ll_count(listaVentas,venta_cantidadMayor2);
    lcd = ll_count(listaVentas,venta_cantidadTvsLcd);

    venta_saveAsText("informes.txt",cantidad,mayor1,mayor2,lcd);

    return 0;
}
