#ifndef VENTA_H_INCLUDED
#define VENTA_H_INCLUDED

typedef struct
{
  int id;
  char fecha[64];
  char codigoProducto[64];
  int cantidad;
  float precioUnitario;
  char cuit[64];
}eVenta;

eVenta* venta_new();
void venta_delete();
eVenta* venta_newConParametros(char* id,char* fecha,char* codigoProducto,char* cantidad,char* precioUnitario,char* cuit);

int venta_setId(eVenta* this,int id);
int venta_getId(eVenta* this,int* id);

int venta_setFecha(eVenta* this,char* fecha);
int venta_getFecha(eVenta* this,char* fecha);

int venta_setCodigoProducto(eVenta* this,char* codigoProducto);
int venta_getCodigoProducto(eVenta* this,char* codigoProducto);

int venta_setCantidad(eVenta* this,int cantidad);
int venta_getCantidad(eVenta* this,int* cantidad);

int venta_setPrecioUnitario(eVenta* this,float precioUnitario);
int venta_getPrecioUnitario(eVenta* this,float* precioUnitario);

int venta_setCuit(eVenta* this,char* cuit);
int venta_getCuit(eVenta* this,char* cuit);

int venta_cantidad(void* element);
int venta_cantidadMayor1(void* element);
int venta_cantidadMayor2(void* element);
int venta_cantidadTvsLcd(void* element);
int venta_saveAsText(char* path ,int cantidad,int mayor1,int mayor2,int lcd);

#endif // VENTA_H_INCLUDED
