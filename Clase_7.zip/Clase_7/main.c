#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main()
{
    char usuario[6];
    char clave[9];
    char auxUser[]="admin\n";
    char auxClave[]="admin\n";

    printf("\nUsuario: ");
    fgets(usuario,16,stdin);
    __fpurge(stdin);
    printf("\nClave: ");

    fgets(clave,9,stdin);
    __fpurge(stdin);

    int otrosAux=strlen(usuario);
    printf("\ntamanio %d\n",otrosAux);

    printf("\nc: %s u: %s",clave,usuario);

    int retorno = strcmp(usuario,clave);
    printf("\nretorno: %d \n",retorno);

  //if(strcmp(usuario,"admin\n")==0);
    if(strcmp(usuario,auxUser)==0 && strcmp(clave,auxClave)==0)
    {
        printf("\nIngresaste pe :v");
    }
    else
    {
        printf("\nNel >:v");
    }
    /*
    char nombre[10];
    char apellido[10];
    char localidad[10];
    int tamanio;
    */
 /*   tamanio=sizeof(nombre);
    printf("antes: %d\n",tamanio);

    printf("Ingrese nombre: ");
    scanf("%s",nombre);

    tamanio=sizeof(nombre);
    printf("\ndespues: %d\n",tamanio);

    printf("El nombre ingresado es: %s y usted es...",nombre);
*/
 /*   fgets(nombre,10,stdin);
    __fpurge(stdin);
    fgets(apellido,10,stdin);
    __fpurge(stdin);
    fgets(localidad,10,stdin);
    __fpurge(stdin);

    printf("\nNombre: %s    Apellido: %s    Localidad: %s",nombre,apellido,localidad);
  */
    return 0;
}
