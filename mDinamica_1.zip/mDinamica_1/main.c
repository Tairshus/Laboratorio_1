#include <stdio.h>
#include <stdlib.h>

#define TAM 10
#define TAM2 20

int inicializar(int*,int,int);
int mostrar(int*,int);
int* new_array(int limite);
int delete_array(int* arrayInt);
int* realloc_array(int* pA,int limite);

int main()
{
    int vInt=2;
    int vIntB=6;
    int* pInt = NULL;
    pInt = new_array(TAM);

    if(pInt != NULL)
    {
        inicializar(pInt,TAM,vInt);

        mostrar(pInt,TAM);
        printf("\n%d",*(pInt+15));

        pInt = realloc_array(pInt,TAM2);

        if (pInt != NULL)
        {
            printf("\nRealloc completado");

            inicializar(pInt,TAM2,vIntB);

            mostrar(pInt,TAM2);

        }

        delete_array(pInt);
    }

    return 0;
}

int inicializar(int* pInt,int limite,int valor)
{
    int retorno = -1;
    int i;

    if(pInt != NULL && limite > 0)
    {
        for(i=0;i<limite;i++)
        {
            *(pInt+i)=valor;
        }
        retorno = 0;
    }
    return retorno;
}

int mostrar(int* pInt,int limite)
{
    int retorno = -1;
    int i;

    printf("\ni --> %p",&i);

    if(pInt != NULL && limite >= 0)
    {
        for(i=0;i<limite;i++)
            {
                printf("\n%p",(pInt+i));
                printf("    [%d]",i);
                printf("    Num: %d",*(pInt+i));
            }
                //printf("\nNum: %d",*(pInt+25));
        retorno = 0;
    }
    return retorno;
}

int* new_array(int limite)
{
    int* retorno = NULL;
    int* auxArrayInt;

    if(limite > 0)
    {
        auxArrayInt = (int*)malloc(sizeof(int)*limite);

        if(auxArrayInt != NULL)
        {
            retorno = auxArrayInt;
        }
    }
    return retorno;
}

int delete_array(int* pInt)
{
    int retorno =-1;
    if(pInt != NULL)
    {
        free(pInt);
        retorno = 0;
    }
    return retorno;
}

int* realloc_array(int* pA,int limite)
{
    int* retorno = NULL;

    if (pA != NULL && limite >= 0)
    {
        retorno = (int*)realloc(pA,sizeof(int)*limite);
    }

    return retorno;
}
